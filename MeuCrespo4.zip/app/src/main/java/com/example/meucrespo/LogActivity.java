package com.example.meucrespo;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.net.Socket;
import java.security.MessageDigest;

import modelDominio.Produto;
import modelDominio.Usuario;

public class LogActivity extends AppCompatActivity {
    Button bEntrar;
    EditText etLoginUser, etSenha;

    Usuario usuario;
    String msgRecebida;

    InformacoesApp informacoesApp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);
        Toolbar toolbar = findViewById(R.id.toolbar);
        bEntrar = findViewById(R.id.bEntrar);
        etLoginUser = findViewById(R.id.etLoginUser);
        etSenha = findViewById(R.id.etSenha);
        setSupportActionBar(toolbar);

        informacoesApp = (InformacoesApp) getApplicationContext();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        bEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!etLoginUser.getText().toString().equals("")) {
                    if (!etSenha.getText().toString().equals("")) {
                        String login = etLoginUser.getText().toString();
                        String senha = etSenha.getText().toString();
                        String hash=null;
                        try {
                            MessageDigest md = MessageDigest.getInstance("MD5"); // MD5, SHA-1, SHA-256
                            BigInteger hashSenha = new BigInteger(1, md.digest(senha.getBytes()));
                            hash = hashSenha.toString();
                            //System.out.println(hash);

                        } catch (Exception e) {
                            System.out.println("Erro ao carregar o MessageDigest");
                        }
                        usuario = new Usuario(login, hash);

                        Thread thread1 = new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    informacoesApp.out.writeObject("EfetuarLogin");
                                    msgRecebida = (String) informacoesApp.in.readObject();
                                    if (msgRecebida.equals("ok")) {
                                        informacoesApp.out.writeObject(usuario);
                                        usuario = (Usuario) informacoesApp.in.readObject();
                                        if (usuario != null) {
                                            // sugiro que o servidor retorne o usuário com todas as informações do banco. Esse objeto pode estar na com.example.meucrespo.InformacoesApp e ser usado em futuras necessidades
                                            informacoesApp.setUsuarioLogado(usuario);

                                            Intent it = new Intent(LogActivity.this, ProdutosRecyclerActivity.class);
                                            startActivity(it);
                                        } else {
                                            runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    Toast.makeText(informacoesApp, "ATENÇÃO: Usuário e senha não conferem!", Toast.LENGTH_SHORT).show();
                                                    limpaCampos();
                                                }
                                            });
                                        }
                                    } else {
                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                Toast.makeText(informacoesApp, "ERRO ao tentar se autenticar!", Toast.LENGTH_SHORT).show();
                                                limpaCampos();
                                            }
                                        });
                                    }

                                } catch (IOException ioe) {
                                    ioe.printStackTrace();
                                } catch (ClassNotFoundException classe) {
                                    classe.printStackTrace();
                                }
                            }
                        });
                        thread1.start();
                    } else {
                        etSenha.setError("Informe a senha!");
                        etSenha.requestFocus();
                    }
                } else {
                    etLoginUser.setError("Informe o usuário!");
                    etLoginUser.requestFocus();
                }
            }
        });

    }

    public void limpaCampos() {
        etSenha.setText("");
        etLoginUser.setText("");
    }
}



