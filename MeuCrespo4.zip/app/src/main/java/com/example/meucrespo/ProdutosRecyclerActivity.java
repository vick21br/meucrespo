package com.example.meucrespo;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;

import modelDominio.Produto;

public class ProdutosRecyclerActivity extends AppCompatActivity {
    RecyclerView rvProdutos;
    ProdutosAdapter produtosAdapter;


    ArrayList<Produto> listaProdutos;

    InformacoesApp informacoesApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produtos_recycler);
        rvProdutos = findViewById(R.id.rvProdutos);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        informacoesApp = (InformacoesApp) getApplicationContext();

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    informacoesApp.out.writeObject("ProdutoLista");
                    listaProdutos = (ArrayList<Produto>) informacoesApp.in.readObject();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            produtosAdapter = new ProdutosAdapter(listaProdutos, trataCliqueItem);
                            rvProdutos.setLayoutManager(new LinearLayoutManager(informacoesApp));
                            rvProdutos.setItemAnimator(new DefaultItemAnimator());
                            rvProdutos.setAdapter(produtosAdapter);
                        }
                    });

                } catch (IOException ioe) {
                    ioe.printStackTrace();
                } catch (ClassNotFoundException classe) {
                    classe.printStackTrace();
                }
            }
        });
        thread.start();


    }
    ProdutosAdapter.ProdutoOnClickListener trataCliqueItem = new ProdutosAdapter.ProdutoOnClickListener() {
        @Override
        public void onClickProduto(View view, int position) {
            Produto meuProduto = listaProdutos.get(position);
            if (meuProduto == null) {
                Intent it = new Intent(ProdutosRecyclerActivity.this, MainActivity.class);
                startActivity(it);
            } else {
                Intent it = new Intent(ProdutosRecyclerActivity.this, FinalizaPedidos.class);
                it.putExtra("produto", meuProduto);
                startActivity(it);
            }

        }
    };
}


