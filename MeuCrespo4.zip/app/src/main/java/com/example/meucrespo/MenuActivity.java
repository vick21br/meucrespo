package com.example.meucrespo;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class MenuActivity extends AppCompatActivity {
Button bCadastro, bLogin;
InformacoesApp informacoesApp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        Toolbar toolbar = findViewById(R.id.toolbar);
        Button bCadastro = findViewById(R.id.bCadastro);
        Button bLogin = findViewById(R.id.bLogin);
        setSupportActionBar(toolbar);

        informacoesApp = (InformacoesApp) getApplicationContext();


        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        bCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(MenuActivity.this, CadActivity.class);
                startActivity(it);
            }
        });
        

        bLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent (MenuActivity.this, LogActivity.class);
                startActivity(it);
            }
        });
    }

}
