package com.example.meucrespo;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import com.example.meucrespo.InformacoesApp;

public class MainActivity extends AppCompatActivity {
    Button bContinuar;

    InformacoesApp informacoesApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button bContinuar = findViewById(R.id.bContinuar);

        informacoesApp = (InformacoesApp) getApplicationContext();
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                //quando rodado no celular, usar como host ip do computador
                //                //                //quando rodado no emulador, host "10.0.2.2"
                //desativar o firewall se nao funcionar
                try {
                    informacoesApp.socket = new Socket("192.168.2.103", 12345);
                    informacoesApp.out = new ObjectOutputStream(informacoesApp.socket.getOutputStream());
                    informacoesApp.in = new ObjectInputStream(informacoesApp.socket.getInputStream());

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(informacoesApp, "Conexão efetuada com sucesso!", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (IOException ioe) {
                    ioe.printStackTrace();
                }
            }
        });
        thread.start();



        bContinuar.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                Intent it = new Intent(MainActivity.this, MenuActivity.class);
                startActivity(it);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
