package com.example.meucrespo;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;

import java.io.Serializable;

import modelDominio.Pedido;

public class FinalActivity extends AppCompatActivity {
    Button bInicio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);
        Toolbar toolbar = findViewById(R.id.toolbar);
        bInicio = findViewById(R.id.bInicio);
        setSupportActionBar(toolbar);

        bInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent (FinalActivity.this, MainActivity.class);
                startActivity(it);
            }
        });

        Intent it = getIntent();
        if (it != null && it.hasExtra("pedido")) {
            Serializable objetoSerializado = it.getSerializableExtra("pedido");
            if (objetoSerializado instanceof Pedido) {
                Pedido pedido = (Pedido) objetoSerializado;
                // agora você pode usar o objeto meuPedido normalmente
            } else {
                // lança uma exceção ou exibe uma mensagem de erro
            }
        } else {
            // lança uma exceção ou exibe uma mensagem de erro
        }
    }

}
