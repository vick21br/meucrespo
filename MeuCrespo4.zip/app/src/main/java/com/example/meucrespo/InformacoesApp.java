package com.example.meucrespo;

import android.app.Application;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import modelDominio.Pedido;
import modelDominio.Produto;
import modelDominio.Usuario;

public class InformacoesApp extends Application {
    Socket socket;
    ObjectOutputStream out;
    ObjectInputStream in;

    private Usuario usuarioLogado;
    private Usuario usuarioNovo;
    private Produto listaProdutos;
    private Pedido pedidoNovo;

    @Override
    public void onCreate() {
        super.onCreate();

    }


    public Usuario getUsuarioNovo() {
        return usuarioNovo;
    }

    public void setUsuarioNovo(Usuario usuarioNovo) {
        this.usuarioNovo = usuarioNovo;
    }

    public Usuario getUsuarioLogado() {
        return usuarioLogado;
    }

    public void setUsuarioLogado(Usuario usuarioLogado) {
        this.usuarioLogado = usuarioLogado;
    }

    public Produto getListaProdutos() {
        return listaProdutos;
    }

    public void setListaProdutos(Produto listaProdutos) {
        this.listaProdutos = listaProdutos;
    }

    public Pedido getPedidoNovo() {
        return pedidoNovo;
    }

    public void setPedidoNovo(Pedido pedidoNovo) {
        this.pedidoNovo = pedidoNovo;
    }
}


