package com.example.meucrespo;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import modelDominio.Usuario;

public class CadActivity extends AppCompatActivity {
    Button bEntrar;
    EditText etEmail, etSenha, etNomeUser, etLoginUser;
    String msgRecebida;

    Usuario usuario;
    InformacoesApp informacoesApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cad);
        Toolbar toolbar = findViewById(R.id.toolbar);
        bEntrar = findViewById(R.id.bEntrar);
        etLoginUser = findViewById(R.id.etLoginUser);
        etEmail = findViewById(R.id.etEmail);
        etSenha = findViewById(R.id.etSenha);
        etNomeUser = findViewById(R.id.etNomeUser);

        setSupportActionBar(toolbar);

        informacoesApp = (InformacoesApp) getApplicationContext();


        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        //problema na thread


        bEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!etNomeUser.getText().toString().equals("")){
                    if (!etLoginUser.getText().toString().equals("")) {
                        if (!etEmail.getText().toString().equals("")) {
                            if(!etSenha.getText().toString().equals("")) {
                                String nomeUser = etNomeUser.getText().toString();
                                String login = etLoginUser.getText().toString();
                                String email = etEmail.getText().toString();
                                String senha = etSenha.getText().toString();

                                usuario = new Usuario(nomeUser, login, senha, email);


                                Thread thread1 = new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            informacoesApp.out.writeObject("inserir");
                                            msgRecebida = (String) informacoesApp.in.readObject();
                                            if (msgRecebida.equals("ok")) {
                                                informacoesApp.out.writeObject(usuario);
                                                usuario = (Usuario) informacoesApp.in.readObject();
                                                if (usuario != null) {

                                                    informacoesApp.setUsuarioNovo(usuario);
                                                    Intent it = new Intent(CadActivity.this, MenuActivity.class);
                                                    startActivity(it);
                                                    System.out.println("Usuário criado! Realize o login.");
                                                } else {
                                                    runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            limpaCampos();
                                                        }
                                                    });
                                                }
                                            } else {
                                                runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        limpaCampos();
                                                    }
                                                });
                                            }

                                        } catch (IOException ioe) {
                                            ioe.printStackTrace();
                                        } catch (ClassNotFoundException classe) {
                                            classe.printStackTrace();
                                        }
                                    }
                                });
                                thread1.start();

                            }else{
                                etSenha.setError("Informe a senha!");
                                etSenha.requestFocus();
                            }
                            }else{
                            etEmail.setError("Informe o e-mail!");
                            etEmail.requestFocus();
                            }
                        } else {
                        etLoginUser.setError("Informe o login!");
                        etLoginUser.requestFocus();
                        }
                    } else {
                    etNomeUser.setError("Informe o nome de usuário!");
                    etNomeUser.requestFocus();
                    }
            }
        });
    }
    public void limpaCampos() {
        etSenha.setText("");
        etNomeUser.setText("");
        etLoginUser.setText("");
        etEmail.setText("");
    }
}

