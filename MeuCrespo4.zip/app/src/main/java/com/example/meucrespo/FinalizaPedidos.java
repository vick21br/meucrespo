package com.example.meucrespo;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.net.Inet4Address;

import modelDominio.Pedido;
import modelDominio.Produto;
import java.time.LocalDate;
import java.util.Date;
import java.util.Calendar;

import modelDominio.Usuario;

public class FinalizaPedidos extends AppCompatActivity {
    TextView tvNomeMarca, tvTipoProduto, tvPreco, tvQtd;
    Button bMenos, bMais, bFinalizar, bInicio;
    ImageView ivVisualizaImagem;

    int qtd=0;

    InformacoesApp informacoesApp;
    Pedido pedido;
    Produto meuProduto;

    Usuario usuario;
    String msgRecebida;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finaliza_pedidos);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        informacoesApp = (InformacoesApp) getApplicationContext();

        tvNomeMarca = findViewById(R.id.tvNomeMarca);
        tvTipoProduto = findViewById(R.id.tvTipoProduto);
        tvPreco = findViewById(R.id.tvPreco);

        ivVisualizaImagem = findViewById(R.id.ivVisualizaImagem);

        bMenos = findViewById(R.id.bMenos);
        bMais = findViewById(R.id.bMais);
        tvQtd = findViewById(R.id.tvQtd);
        bFinalizar = findViewById(R.id.bFinalizar);
        bInicio = findViewById(R.id.bInicio);

        bInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(FinalizaPedidos.this, MainActivity.class);
                startActivity(it);
            }
        });

        bMenos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                qtd = Integer.parseInt(tvQtd.getText().toString());
                if(qtd>=0) {
                    qtd--;
                    System.out.println(qtd);
                    tvQtd.setText(String.valueOf(qtd));
                } else{
                    Toast.makeText(FinalizaPedidos.this, "Comando inválido!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        bMais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 qtd = Integer.parseInt(tvQtd.getText().toString());
                    qtd++;
                    tvQtd.setText(String.valueOf(qtd));
            }
        });

        Bitmap imagembit = null;

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent it = getIntent();
        if (it != null && it.hasExtra("produto")) {
            // obtendo objeto recebido como parametro
            meuProduto = (Produto) it.getSerializableExtra("produto");
            // carregando a tela com as informacoes recebidas

            byte[] imagem = meuProduto.getImagem();

            if (imagem != null) {
                imagembit = BitmapFactory.decodeByteArray(imagem, 0, imagem.length);
                ivVisualizaImagem.setImageBitmap(imagembit);

            }

            tvTipoProduto.setText(meuProduto.getTipoLiteral());
            tvNomeMarca.setText(meuProduto.getNomeMarca());
            tvPreco.setText(String.valueOf(meuProduto.getPreco()));


            bFinalizar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                        int codUser = informacoesApp.getUsuarioLogado().getCodUsuario();
                        float valorTotal = (meuProduto.getPreco()*qtd) ;

                        pedido = new Pedido(meuProduto, valorTotal, codUser);

                        Thread thread1 = new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    informacoesApp.out.writeObject("PedidoInserir");
                                    msgRecebida = (String) informacoesApp.in.readObject();
                                    if (msgRecebida.equals("OK")) {
                                        informacoesApp.out.writeObject(pedido);
                                        pedido = (Pedido) informacoesApp.in.readObject();
                                        if (pedido != null) {
                                            informacoesApp.setPedidoNovo(pedido);
                                            Intent it = new Intent(FinalizaPedidos.this, FinalActivity.class);
                                            it.putExtra("pedido", pedido);
                                            startActivity(it);

                                        } else {
                                            runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    Toast.makeText(informacoesApp, "ERRO", Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                        }
                                    } else {
                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                Toast.makeText(informacoesApp, "ERRO", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                    }

                                } catch (IOException ioe) {
                                    ioe.printStackTrace();
                                } catch (ClassNotFoundException classe) {
                                    classe.printStackTrace();
                                }
                            }
                        });
                        thread1.start();
                }

            });
            }
    }

}