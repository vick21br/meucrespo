package com.example.meucrespo;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import modelDominio.Produto;

public class ProdutosAdapter extends RecyclerView.Adapter<ProdutosAdapter.MyViewHolder> {
    Bitmap imagembit = null;
    private List<Produto> listaProdutos;
    private ProdutoOnClickListener produtoOnClickListener;

    public ProdutosAdapter(List<Produto> listaProdutos, ProdutoOnClickListener produtoOnClickListener) {
        this.listaProdutos = listaProdutos;
        this.produtoOnClickListener = produtoOnClickListener;
    }

    @Override
    public ProdutosAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_list_row, parent, false);

        return new MyViewHolder(itemView);
    }






@Override
    public void onBindViewHolder(final ProdutosAdapter.MyViewHolder holder, final int position) {

        Produto meuProduto = listaProdutos.get(position);
        byte[] imagem = meuProduto.getImagem();

        if (imagem != null) {
            imagembit = BitmapFactory.decodeByteArray(imagem, 0, imagem.length);
            holder.ivImagem.setImageBitmap(imagembit);
            holder.tvTipoProduto.setText(meuProduto.getTipoLiteral());
            holder.tvNomeMarca.setText(meuProduto.getNomeMarca());
            holder.tvPreco.setText("Preço: R$ " + String.valueOf(meuProduto.getPreco()));
        } else {
            holder.ivImagem.setImageResource(R.drawable.logomc);
            holder.tvTipoProduto.setText(meuProduto.getTipoLiteral());
            holder.tvNomeMarca.setText(meuProduto.getNomeMarca());
            holder.tvPreco.setText("Preço: R$ " + String.valueOf(meuProduto.getPreco()));
        }

        /* CUIDADO: .setText() precisa sempre de String. Se for outro tipo de dado (sem concatenação), deve ser feita a conversão com o String.valueOf() */

        // clique no item do cliente
        if (produtoOnClickListener != null) {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    produtoOnClickListener.onClickProduto(holder.itemView,position);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return listaProdutos.size();
    }



    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvTipoProduto, tvNomeMarca, tvPreco;
        ImageView ivImagem;
        public MyViewHolder(View itemView) {
            super(itemView);
            tvTipoProduto = (TextView) itemView.findViewById(R.id.tvTipoProduto);
            tvNomeMarca = (TextView) itemView.findViewById(R.id.tvNomeMarca);
            tvPreco = (TextView) itemView.findViewById(R.id.tvPreco);
            ivImagem = (ImageView)  itemView.findViewById(R.id.ivImagem);
        }
    }

    public interface ProdutoOnClickListener {
        public void onClickProduto(View view, int position);
    }

}

