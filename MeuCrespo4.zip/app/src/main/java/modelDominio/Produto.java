package modelDominio;

import java.io.Serializable;
import java.text.DecimalFormat;


public class Produto implements Serializable {

    private static final long serialVersionUID = 123456789L;

    public int codProduto;
    private int tipoProduto; //1 - shampoo, 2 - condicionador, 3 - creme
    private float preco;
    private int estoque;
    private byte[] imagem;
    private String nomeMarca;

    //é utilixado para edições e para visualizar a tela
    public Produto(int codProduto, int tipoProduto, float preco, int estoque, byte[] imagem, String nomeMarca) {
        this.codProduto = codProduto;
        this.tipoProduto = tipoProduto;
        this.preco = preco;
        this.estoque = estoque;
        this.imagem = imagem;
        this.nomeMarca = nomeMarca;
    }

    //inserir
    public Produto(int tipoProduto, float preco, int estoque, byte[] imagem, String nomeMarca) {
        this.tipoProduto = tipoProduto;
        this.preco = preco;
        this.estoque = estoque;
        this.imagem = imagem;
        this.nomeMarca = nomeMarca;
    }

    //excluir
    public Produto(int codProduto) {
        this.codProduto = codProduto;
    }

    public int getCodProduto() {
        return codProduto;
    }

    public void setCodProduto(int codProduto) {
        this.codProduto = codProduto;
    }

    public int getTipoProduto() {
        return tipoProduto;
    }

    public String getTipoLiteral(){
        String retorno = "";
        if (this.tipoProduto == 1){
            retorno = "Shampoo";
        } else if (this.tipoProduto == 2){
            retorno ="Condicionador";
        } else if (this.tipoProduto == 3) {
            retorno ="Creme";
        }
        return retorno;
    }

    public void setTipoProduto(int tipoProduto) {
        this.tipoProduto = tipoProduto;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public int getEstoque() {
        return estoque;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

    public String getNomeMarca() {
        return nomeMarca;
    }

    public void setNomeMarca(String nomeMarca) {
        this.nomeMarca = nomeMarca;
    }

    public byte[] getImagem() {
        return imagem;
    }

    public void setImagem(byte[] imagem) {
        this.imagem = imagem;
    }


    public String getPrecoString() {
        String padrao = "#,##0.00";
        DecimalFormat dcf = new DecimalFormat(padrao);
        return dcf.format(preco);
    }




}
