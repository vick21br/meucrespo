package modelDominio;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Pedido implements Serializable {

    private static final long serialVersionUID = 123456789L;

    private int codPedido;
    private float valorTotal;
    private Date dataPedido;
    private int codUser;
    private Produto produto; //usar codProduto e


    //inserir android
    //é utilixado para edições e para visualizar a tela
    public Pedido(Produto produto, float valorTotal,  int codUser){
        this.produto = produto;
        this.valorTotal = valorTotal;
        this.codUser = codUser;
    }
//apagar?
    //visualizar
    public Pedido(Produto produto, int codPedido, float valorTotal, Date dataPedido, int codUser){
        this.produto = produto;
        this.codPedido = codPedido;
        this.valorTotal = valorTotal;
        this.dataPedido = dataPedido;
        this.codUser = codUser;
    }

    public float getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(float valorTotal) {
        this.valorTotal = valorTotal;
    }

    public Date getDataPedido() {
        return dataPedido;
    }

    public void setDataPedido(Date dataPedido) {
        this.dataPedido = dataPedido;
    }

    public int getCodUser() {
        return codUser;
    }

    public void setCodUser(int codUser) {
        this.codUser = codUser;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }


    public int getCodPedido() {
        return codPedido;
    }

    public void setCodPedido(int codPedido) {
        this.codPedido = codPedido;
    }

    public String getValorItemString() {
        String padrao = "#,##0.00";
        DecimalFormat dcf = new DecimalFormat(padrao);
        return dcf.format(valorTotal);
    }

    public String getDataPedidoString(){
        String padrao = "dd/MM/yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(padrao);
        return sdf.format(dataPedido);
    }

    @Override
    public String toString() {
        return "Pedido{" + "codPedido=" + codPedido + ", valorPedido=" + valorTotal + ", dataPedido=" + dataPedido + ", codUser=" + codUser + ", produto=" + produto + '}';
    }

}
